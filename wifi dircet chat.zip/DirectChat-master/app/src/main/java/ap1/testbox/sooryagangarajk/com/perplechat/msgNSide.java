package ap1.testbox.sooryagangarajk.com.perplechat;

public class msgNSide {
    String msg;
    boolean side;
}

# DirectChat :globe_with_meridians:
Chatting application build for android platform
App communicates through wifi direct, which is fast and easy to connect.
This app will help you to understand how to make a wifi direct app for android.

**IF YOU FIND ANY BUGS OR ANY BETTER CORE YOU CAN [PULL REQUEST](https://github.com/0xpulsar/DirectChat/pulls)**
### [//// S G K ////](http://sgkcreations.blogspot.in)
